import calc.mvc.*;
public class CalcMain {
    public static void main(String[] args) {
        CalcView view = new CalcView();

        view.showGUI();
    }
}